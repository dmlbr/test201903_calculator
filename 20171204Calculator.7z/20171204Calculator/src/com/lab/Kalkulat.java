package com.lab;

public class Kalkulat {
	
	


	public static double summa (double a, double b) {
		
		return a + b;
		
		
	}
	
	public static double mnorzenie (double a, double b) {
		
		return a * b;
		
	}
	
	public static double minus (double a, double b) {
		
		return a - b;
		
	}
	
	public static double dzielienie (double a, double b) {
		
		return a / b;
		
	}
	
	public static double module (double a, double b) {
		
		return a % b;
		
	}

}
